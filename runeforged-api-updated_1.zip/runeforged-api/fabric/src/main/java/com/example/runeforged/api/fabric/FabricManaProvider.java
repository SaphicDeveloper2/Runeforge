package com.example.runeforged.api.fabric;

import com.example.runeforged.api.RuneforgedAPI;
import com.example.runeforged.api.mana.BaseManaProvider;
import com.example.runeforged.api.mana.ManaType;
import dev.architectury.networking.NetworkManager;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

import java.util.Map;

/**
 * Fabric implementation of the mana provider.
 */
public class FabricManaProvider extends BaseManaProvider {
    private static final ResourceLocation SYNC_PACKET_ID = new ResourceLocation(RuneforgedAPI.MOD_ID, "sync_mana");
    
    /**
     * Create a new Fabric mana provider for an entity.
     *
     * @param entity The entity to provide mana for
     */
    public FabricManaProvider(LivingEntity entity) {
        super(entity);
    }
    
    @Override
    public void sync() {
        if (entity instanceof ServerPlayer serverPlayer) {
            FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
            
            // Write entity ID
            buf.writeInt(entity.getId());
            
            // Write mana data
            Map<ManaType, Integer> currentManaMap = getAllCurrentMana();
            Map<ManaType, Integer> maxManaMap = getAllMaxMana();
            
            // Write number of mana types
            buf.writeInt(getSupportedManaTypes().size());
            
            // Write each mana type
            for (ManaType type : getSupportedManaTypes()) {
                buf.writeResourceLocation(type.getId());
                buf.writeInt(currentManaMap.getOrDefault(type, 0));
                buf.writeInt(maxManaMap.getOrDefault(type, type.getDefaultMaxAmount()));
                buf.writeFloat(getRegenRate(type));
            }
            
            // Send packet to client
            ServerPlayNetworking.send(serverPlayer, SYNC_PACKET_ID, buf);
        }
    }
    
    /**
     * Copy mana data from another provider.
     *
     * @param other The provider to copy from
     */
    public void copyFrom(FabricManaProvider other) {
        this.currentMana.clear();
        this.maxMana.clear();
        this.regenRates.clear();
        
        this.currentMana.putAll(other.currentMana);
        this.maxMana.putAll(other.maxMana);
        this.regenRates.putAll(other.regenRates);
        
        sync();
    }
    
    /**
     * Register the network packet handler for mana synchronization.
     */
    public static void registerNetworkHandler() {
        // This would be called during mod initialization
        // The client would handle the packet and update the client-side mana data
    }
}

