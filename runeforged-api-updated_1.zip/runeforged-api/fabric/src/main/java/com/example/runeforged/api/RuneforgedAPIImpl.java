package com.example.runeforged.api;

import com.example.runeforged.api.fabric.FabricManaProvider;
import com.example.runeforged.api.fabric.FabricPlatformHelper;
import com.example.runeforged.api.mana.IManaProvider;
import dev.architectury.utils.GameInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Fabric implementation of platform-specific methods in RuneforgedAPI.
 */
public class RuneforgedAPIImpl {
    private static final Map<UUID, FabricManaProvider> MANA_PROVIDERS = new HashMap<>();
    private static final IPlatformHelper PLATFORM_HELPER = new FabricPlatformHelper();
    
    /**
     * Get the platform helper implementation.
     *
     * @return The platform helper
     */
    public static IPlatformHelper getPlatform() {
        return PLATFORM_HELPER;
    }
    
    /**
     * Get the mana provider for an entity.
     *
     * @param entity The entity to get the mana provider for
     * @return The mana provider
     */
    public static IManaProvider getManaProvider(Object entityObj) {
        if (!(entityObj instanceof LivingEntity entity)) {
            return null;
        }
        
        // For players, store the provider in a map to ensure it persists
        if (entity instanceof Player) {
            return MANA_PROVIDERS.computeIfAbsent(entity.getUUID(), uuid -> new FabricManaProvider(entity));
        }
        
        // For other entities, create a new provider each time
        return new FabricManaProvider(entity);
    }
}

