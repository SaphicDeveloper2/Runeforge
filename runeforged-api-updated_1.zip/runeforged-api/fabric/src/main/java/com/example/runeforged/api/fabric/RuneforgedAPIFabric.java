package com.example.runeforged.api.fabric;

import com.example.runeforged.api.RuneforgedAPI;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/**
 * Fabric implementation of the Runeforged API.
 */
public class RuneforgedAPIFabric implements ModInitializer {
    @Override
    public void onInitialize() {
        // Initialize the API
        RuneforgedAPI.init();
        
        // Register Fabric-specific event handlers
        registerEvents();
    }
    
    /**
     * Register Fabric-specific event handlers.
     */
    private void registerEvents() {
        // Handle player respawn to copy mana data
        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
            FabricManaProvider oldProvider = (FabricManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(oldPlayer);
            FabricManaProvider newProvider = (FabricManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(newPlayer);
            
            if (oldProvider != null && newProvider != null) {
                newProvider.copyFrom(oldProvider);
            }
        });
        
        // Handle player changing dimensions to sync mana data
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            FabricManaProvider provider = (FabricManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(player);
            if (provider != null) {
                provider.sync();
            }
        });
        
        // Handle mana regeneration
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            server.getPlayerList().getPlayers().forEach(player -> {
                FabricManaProvider provider = (FabricManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(player);
                if (provider != null) {
                    provider.updateRegeneration(1.0f / 20.0f); // 1/20 second per tick
                }
            });
        });
    }
}

