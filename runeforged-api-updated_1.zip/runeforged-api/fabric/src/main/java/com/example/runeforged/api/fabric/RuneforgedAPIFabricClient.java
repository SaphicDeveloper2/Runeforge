package com.example.runeforged.api.fabric;

import com.example.runeforged.api.RuneforgedAPI;
import net.fabricmc.api.ClientModInitializer;

/**
 * Client-side initialization for the Runeforged API on Fabric.
 */
public class RuneforgedAPIFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Initialize client-side components
        RuneforgedAPI.initClient();
    }
}

