package com.example.runeforged.api.mana;

import com.example.runeforged.api.RuneforgedAPI;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

import java.util.*;

/**
 * Base implementation of the IManaProvider interface.
 * This class provides common functionality for both platforms.
 */
public abstract class BaseManaProvider implements IManaProvider {
    protected final LivingEntity entity;
    protected final Map<ManaType, Integer> currentMana = new HashMap<>();
    protected final Map<ManaType, Integer> maxMana = new HashMap<>();
    protected final Map<ManaType, Float> regenRates = new HashMap<>();
    
    /**
     * Create a new base mana provider for an entity.
     *
     * @param entity The entity to provide mana for
     */
    public BaseManaProvider(LivingEntity entity) {
        this.entity = entity;
        
        // Initialize with the default mana type
        if (RuneforgedAPI.ManaRegistry.DEFAULT_MANA != null) {
            addManaType(RuneforgedAPI.ManaRegistry.DEFAULT_MANA);
        }
    }
    
    @Override
    public int getCurrentMana(ManaType manaType) {
        return currentMana.getOrDefault(manaType, 0);
    }
    
    @Override
    public int getMaxMana(ManaType manaType) {
        return maxMana.getOrDefault(manaType, manaType.getDefaultMaxAmount());
    }
    
    @Override
    public void setCurrentMana(ManaType manaType, int amount) {
        int oldValue = getCurrentMana(manaType);
        int newValue = Math.max(0, Math.min(amount, getMaxMana(manaType)));
        
        if (oldValue != newValue) {
            boolean allowed = ManaEvent.MANA_SET.invoker().onChange(entity, this, manaType, oldValue, newValue);
            
            if (allowed) {
                currentMana.put(manaType, newValue);
                sync();
            }
        }
    }
    
    @Override
    public void setMaxMana(ManaType manaType, int amount) {
        int oldValue = getMaxMana(manaType);
        int newValue = Math.max(1, amount);
        
        if (oldValue != newValue) {
            boolean allowed = ManaEvent.MAX_MANA_CHANGE.invoker().onChange(entity, this, manaType, oldValue, newValue);
            
            if (allowed) {
                maxMana.put(manaType, newValue);
                
                // Ensure current mana doesn't exceed new max
                int current = getCurrentMana(manaType);
                if (current > newValue) {
                    setCurrentMana(manaType, newValue);
                }
                
                sync();
            }
        }
    }
    
    @Override
    public int addMana(ManaType manaType, int amount) {
        if (amount <= 0) return 0;
        
        int oldValue = getCurrentMana(manaType);
        int max = getMaxMana(manaType);
        int newValue = Math.min(oldValue + amount, max);
        int actualAdded = newValue - oldValue;
        
        if (actualAdded > 0) {
            boolean allowed = ManaEvent.MANA_ADD.invoker().onChange(entity, this, manaType, oldValue, newValue);
            
            if (allowed) {
                currentMana.put(manaType, newValue);
                sync();
                return actualAdded;
            }
        }
        
        return 0;
    }
    
    @Override
    public int removeMana(ManaType manaType, int amount) {
        if (amount <= 0) return 0;
        
        int oldValue = getCurrentMana(manaType);
        int newValue = Math.max(oldValue - amount, 0);
        int actualRemoved = oldValue - newValue;
        
        if (actualRemoved > 0) {
            boolean allowed = ManaEvent.MANA_REMOVE.invoker().onChange(entity, this, manaType, oldValue, newValue);
            
            if (allowed) {
                currentMana.put(manaType, newValue);
                sync();
                return actualRemoved;
            }
        }
        
        return 0;
    }
    
    @Override
    public float getRegenRate(ManaType manaType) {
        return regenRates.getOrDefault(manaType, manaType.getDefaultRegenRate());
    }
    
    @Override
    public void setRegenRate(ManaType manaType, float rate) {
        regenRates.put(manaType, Math.max(0, rate));
        sync();
    }
    
    @Override
    public Set<ManaType> getSupportedManaTypes() {
        Set<ManaType> types = new HashSet<>();
        types.addAll(currentMana.keySet());
        types.addAll(maxMana.keySet());
        types.addAll(regenRates.keySet());
        return types;
    }
    
    @Override
    public Map<ManaType, Integer> getAllCurrentMana() {
        return new HashMap<>(currentMana);
    }
    
    @Override
    public Map<ManaType, Integer> getAllMaxMana() {
        Map<ManaType, Integer> result = new HashMap<>();
        
        for (ManaType type : getSupportedManaTypes()) {
            result.put(type, getMaxMana(type));
        }
        
        return result;
    }
    
    @Override
    public boolean addManaType(ManaType manaType) {
        if (!getSupportedManaTypes().contains(manaType)) {
            currentMana.put(manaType, 0);
            maxMana.put(manaType, manaType.getDefaultMaxAmount());
            regenRates.put(manaType, manaType.getDefaultRegenRate());
            sync();
            return true;
        }
        return false;
    }
    
    @Override
    public boolean removeManaType(ManaType manaType) {
        boolean removed = false;
        
        if (currentMana.containsKey(manaType)) {
            currentMana.remove(manaType);
            removed = true;
        }
        
        if (maxMana.containsKey(manaType)) {
            maxMana.remove(manaType);
            removed = true;
        }
        
        if (regenRates.containsKey(manaType)) {
            regenRates.remove(manaType);
            removed = true;
        }
        
        if (removed) {
            sync();
        }
        
        return removed;
    }
    
    /**
     * Update mana regeneration for all mana types.
     * This should be called periodically, typically once per tick.
     *
     * @param deltaSeconds The time elapsed since the last update in seconds
     */
    public void updateRegeneration(float deltaSeconds) {
        for (ManaType type : getSupportedManaTypes()) {
            float regenRate = getRegenRate(type);
            
            if (regenRate > 0 && getCurrentMana(type) < getMaxMana(type)) {
                float amountToRegen = regenRate * deltaSeconds;
                int intRegen = (int) amountToRegen;
                float fractionalRegen = amountToRegen - intRegen;
                
                // Add a chance for an extra point based on the fractional part
                if (entity.getRandom().nextFloat() < fractionalRegen) {
                    intRegen += 1;
                }
                
                if (intRegen > 0) {
                    int oldValue = getCurrentMana(type);
                    int newValue = Math.min(oldValue + intRegen, getMaxMana(type));
                    
                    if (oldValue != newValue) {
                        boolean allowed = ManaEvent.MANA_REGENERATE.invoker().onChange(entity, this, type, oldValue, newValue);
                        
                        if (allowed) {
                            currentMana.put(type, newValue);
                            sync();
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Save mana data to NBT.
     *
     * @param tag The tag to save to
     * @return The tag with saved data
     */
    public CompoundTag saveNBT(CompoundTag tag) {
        ListTag manaList = new ListTag();
        
        for (ManaType type : getSupportedManaTypes()) {
            CompoundTag manaTag = new CompoundTag();
            manaTag.putString("Id", type.getId().toString());
            manaTag.putInt("Current", getCurrentMana(type));
            manaTag.putInt("Max", getMaxMana(type));
            manaTag.putFloat("RegenRate", getRegenRate(type));
            manaList.add(manaTag);
        }
        
        tag.put("ManaTypes", manaList);
        return tag;
    }
    
    /**
     * Load mana data from NBT.
     *
     * @param tag The tag to load from
     */
    public void loadNBT(CompoundTag tag) {
        currentMana.clear();
        maxMana.clear();
        regenRates.clear();
        
        if (tag.contains("ManaTypes", Tag.TAG_LIST)) {
            ListTag manaList = tag.getList("ManaTypes", Tag.TAG_COMPOUND);
            
            for (int i = 0; i < manaList.size(); i++) {
                CompoundTag manaTag = manaList.getCompound(i);
                ResourceLocation id = new ResourceLocation(manaTag.getString("Id"));
                
                RuneforgedAPI.ManaRegistry.getManaType(id).ifPresent(type -> {
                    currentMana.put(type, manaTag.getInt("Current"));
                    maxMana.put(type, manaTag.getInt("Max"));
                    regenRates.put(type, manaTag.getFloat("RegenRate"));
                });
            }
        }
    }
}

