package com.example.runeforged.api.client;

import com.example.runeforged.api.RuneforgedAPI;
import com.example.runeforged.api.mana.ManaType;
import dev.architectury.event.events.client.ClientGuiEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles rendering mana bars on the game screen.
 */
public class ManaBarRenderer {
    private static final List<ManaBar> MANA_BARS = new ArrayList<>();
    private static boolean initialized = false;
    
    /**
     * Initialize the mana bar renderer.
     * This should be called during client initialization.
     */
    public static void init() {
        if (initialized) return;
        
        // Register the default mana bar
        registerDefaultManaBar();
        
        // Register the render event
        ClientGuiEvent.RENDER_HUD.register(ManaBarRenderer::renderManaBarOverlay);
        
        initialized = true;
    }
    
    /**
     * Register the default mana bar.
     */
    private static void registerDefaultManaBar() {
        // Create a mana bar for the default mana type
        ManaBar defaultBar = new ManaBar()
                .setPosition(10, 10)
                .setColor(0x0055FF); // Blue color
        
        registerManaBar(defaultBar);
    }
    
    /**
     * Register a mana bar to be rendered.
     *
     * @param manaBar The mana bar to register
     */
    public static void registerManaBar(ManaBar manaBar) {
        MANA_BARS.add(manaBar);
    }
    
    /**
     * Unregister a mana bar.
     *
     * @param manaBar The mana bar to unregister
     */
    public static void unregisterManaBar(ManaBar manaBar) {
        MANA_BARS.remove(manaBar);
    }
    
    /**
     * Clear all registered mana bars.
     */
    public static void clearManaBar() {
        MANA_BARS.clear();
    }
    
    /**
     * Create and register a new mana bar for a specific mana type.
     *
     * @param manaType The mana type to display
     * @param x The x position
     * @param y The y position
     * @param color The color of the bar
     * @return The created mana bar
     */
    public static ManaBar createManaBar(ManaType manaType, int x, int y, int color) {
        ManaBar bar = new ManaBar(manaType)
                .setPosition(x, y)
                .setColor(color);
        
        registerManaBar(bar);
        return bar;
    }
    
    /**
     * Render all registered mana bars.
     *
     * @param graphics The GUI graphics context
     */
    private static void renderManaBarOverlay(GuiGraphics graphics) {
        Minecraft minecraft = Minecraft.getInstance();
        
        // Only render when in game and not in a menu
        if (minecraft.player != null && minecraft.screen == null) {
            for (ManaBar manaBar : MANA_BARS) {
                manaBar.render(graphics);
            }
        }
    }
}

