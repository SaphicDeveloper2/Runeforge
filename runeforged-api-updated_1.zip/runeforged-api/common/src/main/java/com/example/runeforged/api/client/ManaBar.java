package com.example.runeforged.api.client;

import com.example.runeforged.api.RuneforgedAPI;
import com.example.runeforged.api.mana.IManaProvider;
import com.example.runeforged.api.mana.ManaType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Renders a mana bar in the game UI.
 */
public class ManaBar {
    private static final ResourceLocation MANA_BAR_TEXTURE = new ResourceLocation(RuneforgedAPI.MOD_ID, "textures/gui/mana_bar.png");
    
    // Default position and dimensions
    private int x = 10;
    private int y = 10;
    private int width = 81;
    private int height = 9;
    
    // Customization options
    private int barColor = 0x0000FF; // Blue by default
    private boolean showText = true;
    private boolean showPercentage = false;
    
    // The mana type to display
    private ManaType manaType;
    
    /**
     * Create a new mana bar for the default mana type.
     */
    public ManaBar() {
        this(RuneforgedAPI.ManaRegistry.DEFAULT_MANA);
    }
    
    /**
     * Create a new mana bar for a specific mana type.
     *
     * @param manaType The mana type to display
     */
    public ManaBar(ManaType manaType) {
        this.manaType = manaType;
    }
    
    /**
     * Set the position of the mana bar.
     *
     * @param x The x coordinate
     * @param y The y coordinate
     * @return This mana bar for chaining
     */
    public ManaBar setPosition(int x, int y) {
        this.x = x;
        this.y = y;
        return this;
    }
    
    /**
     * Set the dimensions of the mana bar.
     *
     * @param width The width
     * @param height The height
     * @return This mana bar for chaining
     */
    public ManaBar setDimensions(int width, int height) {
        this.width = width;
        this.height = height;
        return this;
    }
    
    /**
     * Set the color of the mana bar.
     *
     * @param color The color in RGB format (0xRRGGBB)
     * @return This mana bar for chaining
     */
    public ManaBar setColor(int color) {
        this.barColor = color;
        return this;
    }
    
    /**
     * Set whether to show text on the mana bar.
     *
     * @param showText Whether to show text
     * @return This mana bar for chaining
     */
    public ManaBar setShowText(boolean showText) {
        this.showText = showText;
        return this;
    }
    
    /**
     * Set whether to show percentage instead of values.
     *
     * @param showPercentage Whether to show percentage
     * @return This mana bar for chaining
     */
    public ManaBar setShowPercentage(boolean showPercentage) {
        this.showPercentage = showPercentage;
        return this;
    }
    
    /**
     * Set the mana type to display.
     *
     * @param manaType The mana type
     * @return This mana bar for chaining
     */
    public ManaBar setManaType(ManaType manaType) {
        this.manaType = manaType;
        return this;
    }
    
    /**
     * Render the mana bar.
     *
     * @param graphics The GUI graphics context
     */
    public void render(GuiGraphics graphics) {
        Player player = Minecraft.getInstance().player;
        if (player == null || manaType == null) return;
        
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        if (provider == null) return;
        
        int current = provider.getCurrentMana(manaType);
        int max = provider.getMaxMana(manaType);
        
        if (max <= 0) return;
        
        // Calculate the fill percentage
        float percentage = (float) current / max;
        int fillWidth = Math.round(percentage * (width - 2));
        
        // Draw the background
        graphics.blit(MANA_BAR_TEXTURE, x, y, 0, 0, width, height);
        
        // Draw the fill
        if (fillWidth > 0) {
            // Set the color for the fill
            RenderSystem.setShaderColor(
                ((barColor >> 16) & 0xFF) / 255f,
                ((barColor >> 8) & 0xFF) / 255f,
                (barColor & 0xFF) / 255f,
                1.0f
            );
            
            graphics.blit(MANA_BAR_TEXTURE, x + 1, y + 1, 1, 10, fillWidth, height - 2);
            
            // Reset color
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        }
        
        // Draw text if enabled
        if (showText) {
            String text;
            if (showPercentage) {
                text = Math.round(percentage * 100) + "%";
            } else {
                text = current + "/" + max;
            }
            
            // Center the text on the bar
            int textWidth = Minecraft.getInstance().font.width(text);
            int textX = x + (width - textWidth) / 2;
            int textY = y + (height - 8) / 2;
            
            // Draw text with shadow
            graphics.drawString(Minecraft.getInstance().font, text, textX, textY, 0xFFFFFF);
        }
    }
}

