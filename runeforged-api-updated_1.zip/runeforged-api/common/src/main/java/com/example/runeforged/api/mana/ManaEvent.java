package com.example.runeforged.api.mana;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import net.minecraft.world.entity.LivingEntity;

/**
 * Events related to mana changes.
 */
public class ManaEvent {
    /**
     * Event fired when mana is added to an entity.
     * Return false to cancel the mana addition.
     */
    public static final Event<ManaChange> MANA_ADD = EventFactory.createEventResult();
    
    /**
     * Event fired when mana is removed from an entity.
     * Return false to cancel the mana removal.
     */
    public static final Event<ManaChange> MANA_REMOVE = EventFactory.createEventResult();
    
    /**
     * Event fired when mana is set on an entity.
     * Return false to cancel the mana change.
     */
    public static final Event<ManaChange> MANA_SET = EventFactory.createEventResult();
    
    /**
     * Event fired when max mana is changed on an entity.
     * Return false to cancel the max mana change.
     */
    public static final Event<ManaChange> MAX_MANA_CHANGE = EventFactory.createEventResult();
    
    /**
     * Event fired when mana regenerates on an entity.
     * Return false to cancel the mana regeneration.
     */
    public static final Event<ManaChange> MANA_REGENERATE = EventFactory.createEventResult();
    
    /**
     * Functional interface for mana change events.
     */
    @FunctionalInterface
    public interface ManaChange {
        /**
         * Called when mana changes on an entity.
         *
         * @param entity The entity whose mana is changing
         * @param provider The mana provider for the entity
         * @param manaType The type of mana being changed
         * @param oldValue The old mana value
         * @param newValue The new mana value
         * @return True to allow the change, false to cancel it
         */
        boolean onChange(LivingEntity entity, IManaProvider provider, ManaType manaType, int oldValue, int newValue);
    }
}

