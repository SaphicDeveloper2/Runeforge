package com.example.runeforged.api.example;

import com.example.runeforged.api.RuneforgedAPI;
import com.example.runeforged.api.client.ManaBar;
import com.example.runeforged.api.client.ManaBarRenderer;
import com.example.runeforged.api.mana.IManaProvider;
import com.example.runeforged.api.mana.ManaEvent;
import com.example.runeforged.api.mana.ManaType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Example usage of the Runeforged API.
 * This class demonstrates how to use the API in your mod.
 */
public class ExampleUsage {
    // Define a custom mana type
    public static final ManaType FIRE_MANA = new ManaType(
            new ResourceLocation("examplemod", "fire_mana"),
            200,  // Default max amount
            0.5f  // Default regen rate per second
    );
    
    /**
     * Initialize the example.
     * This would be called during your mod's initialization.
     */
    public static void init() {
        // Register your custom mana type
        RuneforgedAPI.ManaRegistry.registerManaType(FIRE_MANA);
        
        // Register event listeners
        registerEventListeners();
    }
    
    /**
     * Initialize client-side components.
     * This would be called during your mod's client initialization.
     */
    public static void initClient() {
        // Create a custom mana bar for fire mana
        ManaBar fireManaBar = new ManaBar(FIRE_MANA)
                .setPosition(10, 30) // Position below the default mana bar
                .setColor(0xFF5500)  // Orange color for fire mana
                .setShowText(true);
        
        // Register the custom mana bar
        ManaBarRenderer.registerManaBar(fireManaBar);
    }
    
    /**
     * Register event listeners for mana events.
     */
    private static void registerEventListeners() {
        // Listen for mana addition events
        ManaEvent.MANA_ADD.register((entity, provider, manaType, oldValue, newValue) -> {
            if (manaType.equals(FIRE_MANA)) {
                // Do something when fire mana is added
                System.out.println("Fire mana added: " + (newValue - oldValue));
            }
            return true; // Allow the mana addition
        });
        
        // Listen for mana removal events
        ManaEvent.MANA_REMOVE.register((entity, provider, manaType, oldValue, newValue) -> {
            if (manaType.equals(FIRE_MANA)) {
                // Do something when fire mana is removed
                System.out.println("Fire mana removed: " + (oldValue - newValue));
            }
            return true; // Allow the mana removal
        });
        
        // Listen for default mana removal events
        ManaEvent.MANA_REMOVE.register((entity, provider, manaType, oldValue, newValue) -> {
            if (manaType.equals(RuneforgedAPI.ManaRegistry.DEFAULT_MANA)) {
                // Do something when default mana is removed
                System.out.println("Default mana removed: " + (oldValue - newValue));
            }
            return true; // Allow the mana removal
        });
    }
    
    /**
     * Example method to add mana to a player.
     *
     * @param player The player to add mana to
     * @param amount The amount of mana to add
     * @return The amount of mana actually added
     */
    public static int addFireMana(Player player, int amount) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            // Ensure the player has the fire mana type
            if (!provider.getSupportedManaTypes().contains(FIRE_MANA)) {
                provider.addManaType(FIRE_MANA);
            }
            
            // Add the mana
            return provider.addMana(FIRE_MANA, amount);
        }
        
        return 0;
    }
    
    /**
     * Example method to add default mana to a player.
     *
     * @param player The player to add mana to
     * @param amount The amount of mana to add
     * @return The amount of mana actually added
     */
    public static int addDefaultMana(Player player, int amount) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            // The default mana type is automatically added to all players
            return provider.addMana(RuneforgedAPI.ManaRegistry.DEFAULT_MANA, amount);
        }
        
        return 0;
    }
    
    /**
     * Example method to use mana for a spell.
     *
     * @param player The player casting the spell
     * @param manaCost The mana cost of the spell
     * @return True if the spell was cast successfully, false otherwise
     */
    public static boolean castFireSpell(Player player, int manaCost) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null && provider.hasMana(FIRE_MANA, manaCost)) {
            // Remove the mana
            provider.removeMana(FIRE_MANA, manaCost);
            
            // Cast the spell (implementation would go here)
            System.out.println("Fire spell cast by " + player.getName().getString());
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Example method to use default mana for a spell.
     *
     * @param player The player casting the spell
     * @param manaCost The mana cost of the spell
     * @return True if the spell was cast successfully, false otherwise
     */
    public static boolean castDefaultSpell(Player player, int manaCost) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null && provider.hasMana(RuneforgedAPI.ManaRegistry.DEFAULT_MANA, manaCost)) {
            // Remove the mana
            provider.removeMana(RuneforgedAPI.ManaRegistry.DEFAULT_MANA, manaCost);
            
            // Cast the spell (implementation would go here)
            System.out.println("Default spell cast by " + player.getName().getString());
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Example method to get a player's current fire mana.
     *
     * @param player The player to check
     * @return The player's current fire mana
     */
    public static int getFireMana(Player player) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            return provider.getCurrentMana(FIRE_MANA);
        }
        
        return 0;
    }
    
    /**
     * Example method to get a player's current default mana.
     *
     * @param player The player to check
     * @return The player's current default mana
     */
    public static int getDefaultMana(Player player) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            return provider.getCurrentMana(RuneforgedAPI.ManaRegistry.DEFAULT_MANA);
        }
        
        return 0;
    }
    
    /**
     * Example method to get a player's maximum fire mana.
     *
     * @param player The player to check
     * @return The player's maximum fire mana
     */
    public static int getMaxFireMana(Player player) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            return provider.getMaxMana(FIRE_MANA);
        }
        
        return 0;
    }
    
    /**
     * Example method to get a player's maximum default mana.
     *
     * @param player The player to check
     * @return The player's maximum default mana
     */
    public static int getMaxDefaultMana(Player player) {
        IManaProvider provider = RuneforgedAPI.ManaRegistry.getManaProvider(player);
        
        if (provider != null) {
            return provider.getMaxMana(RuneforgedAPI.ManaRegistry.DEFAULT_MANA);
        }
        
        return 0;
    }
}

