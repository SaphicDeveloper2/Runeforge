package com.example.runeforged.api;

/**
 * Platform-specific helper interface for the Runeforged API.
 */
public interface IPlatformHelper {
    /**
     * Gets the name of the current platform.
     *
     * @return The name of the current platform.
     */
    String getPlatformName();

    /**
     * Checks if the code is currently running on the client side.
     *
     * @return True if the code is running on the client side, false otherwise.
     */
    boolean isClientSide();

    /**
     * Checks if a mod with the given ID is loaded.
     *
     * @param modId The mod ID to check.
     * @return True if the mod is loaded, false otherwise.
     */
    boolean isModLoaded(String modId);

    /**
     * Gets the name of the environment type as a string.
     *
     * @return The name of the environment type.
     */
    default String getEnvironmentName() {
        return isClientSide() ? "client" : "server";
    }
}

