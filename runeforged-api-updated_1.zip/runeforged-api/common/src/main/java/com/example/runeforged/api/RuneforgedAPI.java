package com.example.runeforged.api;

import com.example.runeforged.api.client.ManaBarRenderer;
import dev.architectury.injectables.annotations.ExpectPlatform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main class for the Runeforged API.
 */
public class RuneforgedAPI {
    public static final String MOD_ID = "runeforged_api";
    public static final Logger LOGGER = LoggerFactory.getLogger("RuneforgedAPI");
    
    /**
     * Called during mod initialization.
     */
    public static void init() {
        LOGGER.info("Initializing Runeforged API");
        
        // Register mana system components
        ManaRegistry.init();
    }
    
    /**
     * Called during client initialization.
     * This is called separately on the client side.
     */
    public static void initClient() {
        LOGGER.info("Initializing Runeforged API Client");
        
        // Initialize client-side components
        ManaBarRenderer.init();
    }
    
    /**
     * Get the platform-specific implementation of the API.
     * 
     * @return The platform-specific implementation
     */
    @ExpectPlatform
    public static IPlatformHelper getPlatform() {
        // This will be implemented in platform-specific modules
        throw new AssertionError();
    }
}

