package com.example.runeforged.api.mana;

import net.minecraft.resources.ResourceLocation;

/**
 * Represents a type of mana in the Runeforged mod.
 */
public class ManaType {
    private final ResourceLocation id;
    private final int defaultMaxAmount;
    private final float defaultRegenRate;
    
    /**
     * Creates a new mana type.
     *
     * @param id The unique identifier for this mana type
     * @param defaultMaxAmount The default maximum amount of this mana type
     * @param defaultRegenRate The default regeneration rate per second
     */
    public ManaType(ResourceLocation id, int defaultMaxAmount, float defaultRegenRate) {
        this.id = id;
        this.defaultMaxAmount = defaultMaxAmount;
        this.defaultRegenRate = defaultRegenRate;
    }
    
    /**
     * Get the unique identifier for this mana type.
     *
     * @return The mana type ID
     */
    public ResourceLocation getId() {
        return id;
    }
    
    /**
     * Get the default maximum amount of this mana type.
     *
     * @return The default maximum amount
     */
    public int getDefaultMaxAmount() {
        return defaultMaxAmount;
    }
    
    /**
     * Get the default regeneration rate per second.
     *
     * @return The default regeneration rate
     */
    public float getDefaultRegenRate() {
        return defaultRegenRate;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        ManaType manaType = (ManaType) o;
        return id.equals(manaType.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
    
    @Override
    public String toString() {
        return "ManaType{" +
                "id=" + id +
                ", defaultMaxAmount=" + defaultMaxAmount +
                ", defaultRegenRate=" + defaultRegenRate +
                '}';
    }
}

