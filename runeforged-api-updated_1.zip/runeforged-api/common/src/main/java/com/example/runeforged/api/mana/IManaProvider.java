package com.example.runeforged.api.mana;

import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.Set;

/**
 * Interface for accessing and manipulating mana on an entity.
 */
public interface IManaProvider {
    /**
     * Get the current amount of a specific mana type.
     *
     * @param manaType The mana type to check
     * @return The current amount of mana
     */
    int getCurrentMana(ManaType manaType);
    
    /**
     * Get the maximum amount of a specific mana type.
     *
     * @param manaType The mana type to check
     * @return The maximum amount of mana
     */
    int getMaxMana(ManaType manaType);
    
    /**
     * Set the current amount of a specific mana type.
     *
     * @param manaType The mana type to modify
     * @param amount The new amount of mana
     */
    void setCurrentMana(ManaType manaType, int amount);
    
    /**
     * Set the maximum amount of a specific mana type.
     *
     * @param manaType The mana type to modify
     * @param amount The new maximum amount of mana
     */
    void setMaxMana(ManaType manaType, int amount);
    
    /**
     * Add mana of a specific type.
     *
     * @param manaType The mana type to add
     * @param amount The amount of mana to add
     * @return The amount of mana actually added
     */
    default int addMana(ManaType manaType, int amount) {
        int current = getCurrentMana(manaType);
        int max = getMaxMana(manaType);
        int newAmount = Math.min(current + amount, max);
        int added = newAmount - current;
        
        if (added > 0) {
            setCurrentMana(manaType, newAmount);
        }
        
        return added;
    }
    
    /**
     * Remove mana of a specific type.
     *
     * @param manaType The mana type to remove
     * @param amount The amount of mana to remove
     * @return The amount of mana actually removed
     */
    default int removeMana(ManaType manaType, int amount) {
        int current = getCurrentMana(manaType);
        int newAmount = Math.max(current - amount, 0);
        int removed = current - newAmount;
        
        if (removed > 0) {
            setCurrentMana(manaType, newAmount);
        }
        
        return removed;
    }
    
    /**
     * Check if there is enough mana of a specific type.
     *
     * @param manaType The mana type to check
     * @param amount The amount of mana required
     * @return True if there is enough mana, false otherwise
     */
    default boolean hasMana(ManaType manaType, int amount) {
        return getCurrentMana(manaType) >= amount;
    }
    
    /**
     * Get the regeneration rate of a specific mana type.
     *
     * @param manaType The mana type to check
     * @return The regeneration rate per second
     */
    float getRegenRate(ManaType manaType);
    
    /**
     * Set the regeneration rate of a specific mana type.
     *
     * @param manaType The mana type to modify
     * @param rate The new regeneration rate per second
     */
    void setRegenRate(ManaType manaType, float rate);
    
    /**
     * Get all mana types supported by this provider.
     *
     * @return A set of all supported mana types
     */
    Set<ManaType> getSupportedManaTypes();
    
    /**
     * Get a map of all mana types and their current amounts.
     *
     * @return A map of mana types to current amounts
     */
    Map<ManaType, Integer> getAllCurrentMana();
    
    /**
     * Get a map of all mana types and their maximum amounts.
     *
     * @return A map of mana types to maximum amounts
     */
    Map<ManaType, Integer> getAllMaxMana();
    
    /**
     * Add a new mana type to this provider.
     *
     * @param manaType The mana type to add
     * @return True if the mana type was added, false if it already existed
     */
    boolean addManaType(ManaType manaType);
    
    /**
     * Remove a mana type from this provider.
     *
     * @param manaType The mana type to remove
     * @return True if the mana type was removed, false if it didn't exist
     */
    boolean removeManaType(ManaType manaType);
    
    /**
     * Synchronize mana data to the client.
     * This is typically called automatically when mana values change.
     */
    void sync();
}

