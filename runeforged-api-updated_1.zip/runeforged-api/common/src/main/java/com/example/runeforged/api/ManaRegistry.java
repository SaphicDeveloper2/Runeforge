package com.example.runeforged.api;

import com.example.runeforged.api.mana.IManaProvider;
import com.example.runeforged.api.mana.ManaType;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Registry for mana types and providers.
 */
public class ManaRegistry {
    private static final Map<ResourceLocation, ManaType> MANA_TYPES = new HashMap<>();
    
    /**
     * The default mana type used by the Runeforged mod.
     * This is the primary mana resource that magic features will use.
     */
    public static ManaType DEFAULT_MANA;
    
    /**
     * Initialize the mana registry.
     */
    public static void init() {
        RuneforgedAPI.LOGGER.info("Initializing Mana Registry");
        registerDefaultManaTypes();
    }
    
    /**
     * Register default mana types.
     */
    private static void registerDefaultManaTypes() {
        // Register the default mana type
        DEFAULT_MANA = registerManaType(new ManaType(
            new ResourceLocation(RuneforgedAPI.MOD_ID, "mana"), 
            200,  // Default max amount
            2.0f  // Default regen rate per second
        ));
        
        RuneforgedAPI.LOGGER.info("Registered default mana type: {}", DEFAULT_MANA.getId());
    }
    
    /**
     * Register a new mana type.
     *
     * @param manaType The mana type to register
     * @return The registered mana type
     */
    public static ManaType registerManaType(ManaType manaType) {
        if (MANA_TYPES.containsKey(manaType.getId())) {
            RuneforgedAPI.LOGGER.warn("Mana type with ID {} already exists, overwriting", manaType.getId());
        }
        
        MANA_TYPES.put(manaType.getId(), manaType);
        RuneforgedAPI.LOGGER.debug("Registered mana type: {}", manaType.getId());
        return manaType;
    }
    
    /**
     * Get a mana type by its ID.
     *
     * @param id The ID of the mana type
     * @return The mana type, or empty if not found
     */
    public static Optional<ManaType> getManaType(ResourceLocation id) {
        return Optional.ofNullable(MANA_TYPES.get(id));
    }
    
    /**
     * Get all registered mana types.
     *
     * @return A map of all registered mana types
     */
    public static Map<ResourceLocation, ManaType> getAllManaTypes() {
        return new HashMap<>(MANA_TYPES);
    }
    
    /**
     * Get the platform-specific mana provider for an entity.
     * This method is implemented differently on each platform.
     *
     * @param entity The entity to get the mana provider for
     * @return The mana provider for the entity
     */
    @ExpectPlatform
    public static IManaProvider getManaProvider(Object entity) {
        // This will be implemented in platform-specific modules
        throw new AssertionError();
    }
}

