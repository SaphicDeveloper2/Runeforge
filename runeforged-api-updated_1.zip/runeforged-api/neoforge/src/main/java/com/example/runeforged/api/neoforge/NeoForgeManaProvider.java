package com.example.runeforged.api.neoforge;

import com.example.runeforged.api.RuneforgedAPI;
import com.example.runeforged.api.mana.BaseManaProvider;
import com.example.runeforged.api.mana.ManaType;
import io.netty.buffer.Unpooled;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;

/**
 * NeoForge implementation of the mana provider.
 */
public class NeoForgeManaProvider extends BaseManaProvider {
    /**
     * Create a new NeoForge mana provider for an entity.
     *
     * @param entity The entity to provide mana for
     */
    public NeoForgeManaProvider(LivingEntity entity) {
        super(entity);
    }
    
    @Override
    public void sync() {
        if (entity instanceof ServerPlayer serverPlayer) {
            FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
            
            // Write entity ID
            buf.writeInt(entity.getId());
            
            // Write mana data
            Map<ManaType, Integer> currentManaMap = getAllCurrentMana();
            Map<ManaType, Integer> maxManaMap = getAllMaxMana();
            
            // Write number of mana types
            buf.writeInt(getSupportedManaTypes().size());
            
            // Write each mana type
            for (ManaType type : getSupportedManaTypes()) {
                buf.writeResourceLocation(type.getId());
                buf.writeInt(currentManaMap.getOrDefault(type, 0));
                buf.writeInt(maxManaMap.getOrDefault(type, type.getDefaultMaxAmount()));
                buf.writeFloat(getRegenRate(type));
            }
            
            // Send packet to client
            RuneforgedAPINeoForge.CHANNEL.send(
                    new ManaSyncPacket(buf),
                    PacketDistributor.PLAYER.with(serverPlayer)
            );
        }
    }
    
    /**
     * Copy mana data from another provider.
     *
     * @param other The provider to copy from
     */
    public void copyFrom(NeoForgeManaProvider other) {
        this.currentMana.clear();
        this.maxMana.clear();
        this.regenRates.clear();
        
        this.currentMana.putAll(other.currentMana);
        this.maxMana.putAll(other.maxMana);
        this.regenRates.putAll(other.regenRates);
        
        sync();
    }
    
    /**
     * Packet class for mana synchronization.
     */
    public static class ManaSyncPacket {
        private final FriendlyByteBuf data;
        
        public ManaSyncPacket(FriendlyByteBuf data) {
            this.data = data;
        }
        
        public FriendlyByteBuf getData() {
            return data;
        }
    }
}

