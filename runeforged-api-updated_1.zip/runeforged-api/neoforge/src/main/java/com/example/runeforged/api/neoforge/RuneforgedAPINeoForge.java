package com.example.runeforged.api.neoforge;

import com.example.runeforged.api.RuneforgedAPI;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.Mod.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerTickEvent;
import net.neoforged.neoforge.network.Channel;
import net.neoforged.neoforge.network.ChannelBuilder;

/**
 * NeoForge implementation of the Runeforged API.
 */
@Mod(RuneforgedAPI.MOD_ID)
public class RuneforgedAPINeoForge {
    // Network channel for mana synchronization
    public static final Channel CHANNEL = ChannelBuilder
            .named(new ResourceLocation(RuneforgedAPI.MOD_ID, "network"))
            .networkProtocolVersion(1)
            .clientAcceptedVersions((status, version) -> true)
            .serverAcceptedVersions((status, version) -> true)
            .simpleChannel();
    
    /**
     * Create a new instance of the NeoForge mod.
     *
     * @param eventBus The mod event bus
     */
    public RuneforgedAPINeoForge(IEventBus eventBus) {
        // Register mod setup
        eventBus.addListener(this::setup);
        eventBus.addListener(this::registerCapabilities);
        eventBus.addListener(this::clientSetup);
        
        // Register forge event handlers
        NeoForge.EVENT_BUS.addListener(this::onPlayerClone);
        NeoForge.EVENT_BUS.addListener(this::onServerTick);
        
        // Initialize the API
        RuneforgedAPI.init();
    }
    
    /**
     * Set up the mod.
     *
     * @param event The setup event
     */
    private void setup(final FMLCommonSetupEvent event) {
        // Register network packets
        registerNetworkPackets();
    }
    
    /**
     * Set up client-side components.
     *
     * @param event The client setup event
     */
    private void clientSetup(final FMLClientSetupEvent event) {
        // Initialize client-side components
        event.enqueueWork(RuneforgedAPI::initClient);
    }
    
    /**
     * Register capabilities.
     *
     * @param event The capability registration event
     */
    private void registerCapabilities(final RegisterCapabilitiesEvent event) {
        // Register mana capability
        // This would be implemented in a real mod
    }
    
    /**
     * Register network packets.
     */
    private void registerNetworkPackets() {
        // Register mana sync packet
        // This would be implemented in a real mod
    }
    
    /**
     * Handle player clone event to copy mana data.
     *
     * @param event The player clone event
     */
    private void onPlayerClone(PlayerEvent.Clone event) {
        NeoForgeManaProvider oldProvider = (NeoForgeManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(event.getOriginal());
        NeoForgeManaProvider newProvider = (NeoForgeManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(event.getEntity());
        
        if (oldProvider != null && newProvider != null) {
            newProvider.copyFrom(oldProvider);
        }
    }
    
    /**
     * Handle server tick event to update mana regeneration.
     *
     * @param event The server tick event
     */
    private void onServerTick(ServerTickEvent event) {
        if (event.phase == ServerTickEvent.Phase.END) {
            event.getServer().getPlayerList().getPlayers().forEach(player -> {
                NeoForgeManaProvider provider = (NeoForgeManaProvider) RuneforgedAPI.ManaRegistry.getManaProvider(player);
                if (provider != null) {
                    provider.updateRegeneration(1.0f / 20.0f); // 1/20 second per tick
                }
            });
        }
    }
}

